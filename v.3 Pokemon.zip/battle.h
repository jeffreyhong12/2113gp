#include<iostream>
using namespace std;

int main_battle();
