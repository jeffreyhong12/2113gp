#include <iostream>
#include <string>
#include <vector>
#include "battle.h"
#include "character.cpp"
#include<ctime>
#include<windows.h>
using namespace std;

void rest() { //����
    cout << endl;
    for (int i = 0;i < 10;i++) {
        cout << "-";
    }
    cout << endl;
}


struct Pokemens {//��Ҿ������ݿ�
    string name;
    int HP;
    int attack;
    int defense;
    string skill;
    int skill_level;
    int skill_attack;
    string skill_effect;
    int controlled_abnormal_state = 0;
    int harmful_abnormal_state = 0;
};

struct Pokemen_ai {//ai���ݿ�
    string name;
    int HP;
    int attack;
    int defense;
    string skill;
    int skill_level;
    int skill_attack;
    string skill_effect;
    int controlled_abnormal_state = 0;
    int harmful_abnormal_state = 0;
};

int Search(Pokemens animal[], string name) {//�ҵ�name��array���λ�� �Ա��ȡarray��������Ϣ
    for (int i = 0;i < 5;i++) {            //���������޸�λ��
        if (name == animal[i].name) {
            return i;
        }
    }
    return -1;
}
int Pokemen_sum_number = 4;
Pokemens Pokemen[10]; //��ҵľ������ݿ�
Pokemens Pokemen_ai[10]; //AI �ľ������ݿ�

void Level_1_input() {
    initial_pig_1 Pikachu;
    initial_pig_2 Bulbasaur;
    initial_pig_3 Dewgong;
    initial_pig_4 Grimer;
    initial_pig_5 Gastly;

    level_1_AI_1 Plusle_AI;
    level_1_AI_2 Weedle_AI;

    Pokemen[0].name = Pikachu.name;
    Pokemen[0].attack = Pikachu.attack;
    Pokemen[0].HP = Pikachu.HP;
    Pokemen[0].defense = Pikachu.defense;
    Pokemen[0].skill = Pikachu.skill;
    Pokemen[0].skill_attack = Pikachu.skill_attack;
    Pokemen[0].skill_effect = Pikachu.skill_effect;
    Pokemen[0].skill_level = Pikachu.skill_level;

    Pokemen[1].name = Bulbasaur.name;
    Pokemen[1].attack = Bulbasaur.attack;
    Pokemen[1].HP = Bulbasaur.HP;
    Pokemen[1].defense = Bulbasaur.defense;

    Pokemen[2].name = Dewgong.name;
    Pokemen[2].attack = Dewgong.attack;
    Pokemen[2].HP = Dewgong.HP;
    Pokemen[2].defense = Dewgong.defense;

    Pokemen[3].name = Grimer.name;
    Pokemen[3].attack = Grimer.attack;
    Pokemen[3].HP = Grimer.HP;
    Pokemen[3].defense = Grimer.defense;

    Pokemen[4].name = Gastly.name;
    Pokemen[4].attack = Gastly.attack;
    Pokemen[4].HP = Gastly.HP;
    Pokemen[4].defense = Gastly.defense;

    Pokemen_ai[0].name = Plusle_AI.name;//��class������ݷŵ�ai animals��
    Pokemen_ai[0].HP = Plusle_AI.HP;
    Pokemen_ai[0].attack = Plusle_AI.attack;
    Pokemen_ai[0].defense = Plusle_AI.attack;
    Pokemen_ai[1].name = Weedle_AI.name;
    Pokemen_ai[1].HP = Weedle_AI.HP;
    Pokemen_ai[1].attack = Weedle_AI.attack;
    Pokemen_ai[1].defense = Weedle_AI.attack;
}


bool alive(Pokemens animal[], int index) {//�ж�����ֵ
    if (animal[index].HP > 0) {
        return true;
    }
    return false;
}

bool lose(vector<string>bag) {//ʤ��������bag��ľ��鶼����
    for (int i = 0;i < bag.size();i++) {
        if (bag[i] != "") {
            return false;
        }
    }
    return true;
}

int level_count = 1;  //�жϴ򵽵ڼ���������

void fight(vector<string>bag,vector<string>bag_ai) {
    int name;
    cout << "Choose your Pokemen to fight: " << endl;
    cout << "Your Pokemen: ";
    for (int i = 0;i < bag.size();i++) {
        cout << i << ":" << bag[i] << " ";
    }
    cout << endl;
    cin >> name;
    cout << bag[name] << " is going to fight!" << endl;
    string pname = bag[name];

    srand((unsigned)time(NULL));
    int choose_ai = (rand() % 1);  //AI ѡ���ս�ľ���
    cout << "AI sent " << bag_ai[choose_ai] << " to fight" << endl;
    int enemy = Search(Pokemen_ai, bag_ai[choose_ai]);//��ȡaiѡ��ľ��������
    int fighting_Pokemen = Search(Pokemen, pname);//��ȡ�Լ����������

    while (true) {
        while (bag[name] == "") {
            name = (rand() % 2);//��ҵľ�������Ǵ��״̬
            fighting_Pokemen = Search(Pokemen, bag[name]);
        }
        cout << "choose your attack style" << endl;   //ѡ�񹥻���ʽ
        cout << "1." << "normal attack     " << "2." << "using skill" << endl;
        int attack_choose;
        cin >> attack_choose;
        Sleep(500);
       
        if (attack_choose == 1) { //ʹ����ͨ����ʱ���˺�����
            cout << bag[name] << " use normal attack" << endl;
            cout << "HP- " << Pokemen[fighting_Pokemen].attack - Pokemen_ai[enemy].defense << endl;
            if (Pokemen_ai[enemy].defense < Pokemen[fighting_Pokemen].attack) { //�ж�AI����������Ƿ����Ҿ��鹥������
                Pokemen_ai[enemy].HP -= (Pokemen[fighting_Pokemen].attack - Pokemen_ai[enemy].defense);//���ݹ�ʽ�۳�ai����������Ѫ��
            }
            else {
                Pokemen_ai[enemy].HP -= 0;
            }
        }
        if (attack_choose == 2) { //ʹ�ü��ܹ���ʱ
            cout << bag[name] << " use " << Pokemen[fighting_Pokemen].skill << endl;
            cout << "HP- " << Pokemen[fighting_Pokemen].skill_attack - Pokemen_ai[enemy].defense << endl;
            if (Pokemen_ai[enemy].defense < Pokemen[fighting_Pokemen].skill_attack) {
                Pokemen_ai[enemy].HP -= (Pokemen[fighting_Pokemen].skill_attack - Pokemen_ai[enemy].defense); //���ݹ�ʽ��Ѫ
            }
            else {
                Pokemen_ai[enemy].HP -= 0;
            }

            srand((unsigned)time(NULL));
            int temp_possible_affect = rand() % 100;
            if (temp_possible_affect > 50) {     //����ʹ�Է����쳣״̬
                if (Pokemen[fighting_Pokemen].skill_effect == "stunned") {   //�ж����������쳣״̬
                    Pokemen_ai[enemy].controlled_abnormal_state += Pokemen[fighting_Pokemen].skill_level;
                }
                else {
                    Pokemen_ai[enemy].harmful_abnormal_state += Pokemen[fighting_Pokemen].skill_level;
                }
                cout << "The skill took effect, causing the opponent to enter an " << Pokemen[fighting_Pokemen].skill_effect << " state" << endl;
                cout << "The opponent will receive abnormal status for " << Pokemen[fighting_Pokemen].skill_level << " round" << endl;
            }
        }

        cout << Pokemen_ai[enemy].name << " has been attacked!" << endl;
        cout << "HP: " << Pokemen_ai[enemy].HP << endl;

        if (!alive(Pokemen_ai, enemy)) {
            cout << Pokemen_ai[enemy].name << " is dead!" << endl;
            bag_ai[choose_ai] = "";
        }
        if (lose(bag_ai)) {
            cout << "You win!";
            Sleep(5000);
            break;
        }
        rest();
        Sleep(500);


        //                  AI �Ĺ����غ�
        cout << "AI's turn!" << endl;
        srand((int)time(0));
        while (bag_ai[choose_ai] == "") {
            choose_ai = (rand() % 2);//������ai ���뻹�Ǵ��״̬
            enemy = Search(Pokemen_ai, bag_ai[choose_ai]);//��ȡaiѡ��ľ��������
        }
        if (Pokemen_ai[enemy].controlled_abnormal_state == 0) {   // �жϾ����Ƿ����޷��ж�״̬
            cout << bag_ai[enemy] << "is going to fight!" << endl;
            cout << bag_ai[enemy] << " is going to attack " << bag[name] << "!" << endl;

            cout << "HP- " << Pokemen_ai[enemy].attack - Pokemen[fighting_Pokemen].defense << endl;

            if (Pokemen[fighting_Pokemen].defense < Pokemen_ai[enemy].attack) { //�ж���Ҿ�������Ƿ��AI��������
                Pokemen[fighting_Pokemen].HP -= (Pokemen_ai[enemy].attack - Pokemen[fighting_Pokemen].defense);//���ݹ�ʽ�۳���Ҿ����Ѫ��
            }
            else {
                Pokemen[fighting_Pokemen].HP -= 0;
            }
            cout << bag[name] << " has been attacked!" << endl;
            cout << "HP: " << Pokemen[fighting_Pokemen].HP << endl;
        }
        else if (Pokemen_ai[enemy].controlled_abnormal_state > 0) { //��غ��޷��ж���������Ч������һ�غ�
            cout << Pokemen_ai[enemy].name << " enter a " << Pokemen[fighting_Pokemen].skill_effect << " state, can't make an action this round" << endl;
            Pokemen_ai[enemy].controlled_abnormal_state -= 1;
        }

        if (!alive(Pokemen, fighting_Pokemen)) {
            cout << Pokemen[fighting_Pokemen].name << " is dead!" << endl;
            bag[name] = "";
        }
        if (lose(bag)) {
            cout << endl << "You lose!";
            Sleep(5000);
            break;
        }
    }
}

int main_battle() {
    switch (level_count) {
        case int(1):
            Level_1_input();
    }
    string name;
    int choose_num; 
    vector<string> bag;//���˱���
    for (int j = 0;j < 2;j++) {//ѡ����
        cout << "The Pokemen you can choose are as follows:" << endl;
        cout << "enter your pet: ";
        for (int i = 0;i < 5;i++) {           //���������޸�λ��
            cout << i <<"."<< Pokemen[i].name << "     ";
        }
        cout << endl;
        cin >> choose_num;  //�����뾫�����ָ�Ϊ�������֣������������
        name = Pokemen[choose_num].name;
        int i = Search(Pokemen, name);
        while (i == -1) {//�������
            cout << "enter your pet:" << endl;
            cin >> choose_num;
            i = Search(Pokemen, name);
        }
        bag.push_back(name);
        cout << "your pet: " << Pokemen[i].name << endl;
        cout << "HP: " << Pokemen[i].HP << endl;
        cout << "Attack: " << Pokemen[i].attack << endl;
        cout << "Defense: " << Pokemen[i].defense << endl;
        cout << "your bag: ";
        for (vector<string>::iterator i = bag.begin();i != bag.end();i++) {
            cout << *i << " ";
        }
        rest();
    }
    // AIѡ���ս����
    srand((int)time(0)); //�����������

    int ai_1 = 0;//(rand())%3;//�������
    int ai_2 = 1;//(rand())%3;//�����
    Sleep(500); //�ӳ����
    cout << "AI_1: " << endl;//����AI����ҶԴ�ÿ��ֻѡһ������������һ�غ� ��δ�����쳣״̬
    cout << Pokemen_ai[ai_1].name << endl;
    cout << Pokemen_ai[ai_1].HP << endl;
    cout << Pokemen_ai[ai_1].attack << endl;
    rest();
    Sleep(500);
    cout << "AI_2: " << endl;
    cout << Pokemen_ai[ai_2].name << endl;
    cout << Pokemen_ai[ai_2].HP << endl;
    cout << Pokemen_ai[ai_2].attack << endl;
    rest();
    vector<string>bag_ai;//ai��ս����
    bag_ai.push_back(Pokemen_ai[ai_1].name);
    bag_ai.push_back(Pokemen_ai[ai_2].name);

    fight(bag,bag_ai);
    return 0;
}