//这里是 精灵的struct和精灵招式的struct
#include <>

struct pokemon(){
  
};

struct skills(){
  
};
